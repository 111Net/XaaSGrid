const logger = (req, res, next) => {

    const start = Date.now();


    res.on("finish", () => {

        const duration = Date.now() - start;


        console.log(
            JSON.stringify({
                timestamp: new Date().toISOString(),
                method: req.method,
                path: req.originalUrl,
                status: res.statusCode,
                duration: `${duration}ms`
            })
        );

    });


    next();

};


module.exports = logger;
